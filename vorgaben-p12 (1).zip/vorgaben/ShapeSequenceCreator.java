import java.awt.*;
import java.awt.geom.*;

public class ShapeSequenceCreator {
    private ShapeAnimFrame.AnimCanvas aCanv;
    private int w,h;

    public ShapeSequenceCreator(int w, int h, ShapeAnimFrame.AnimCanvas aCanv) {
        this.aCanv = aCanv;
        this.w = w;
        this.h = h;

        /* *** rotierendes Windraedchen *** */
        
        ColoredShape cShape1 = createShape_1();
        ColoredShape[] shapeArr1 = createSequence_1(cShape1);
        aCanv.addShapeSequence(shapeArr1);
        

        /* für Aufgabe 1c den folgenden Blockkommentar entfernen */
        /*
        ColoredShape cShape2 = createShape_2();
        ColoredShape[] shapeArr2 = createSequence_2(cShape2);
        aCanv.addShapeSequence(shapeArr2);
        */
        
    }

    /* *** Aufgabe 1c *** */


    public ColoredShape createShape_2(){
        return null; 
    }
    
    public ColoredShape[] createSequence_2(ColoredShape shape) {
        return null;
    }

    
    /* *** Beispielcode (Rotation) *** */
    
    public ColoredShape createShape_1(){
        Shape shape = Windraedchen.getShape();
        double sw = shape.getBounds().getWidth();
        double sh = shape.getBounds().getHeight();
        ColoredShape cShape = new ColoredShape(shape, Color.BLUE, Color.ORANGE, 3.0f);
        cShape.translate((w-sw)/2,(h-sh)/2);
        return cShape;
    }

    
    public ColoredShape[] createSequence_1(ColoredShape shape) {
        ColoredShape[] shapeArr = new ColoredShape[200];
        shapeArr[0] = shape;
        
        double dTheta = 2.0 * Math.PI / shapeArr.length;
        for (int i=1;i<shapeArr.length;i++) {
            shapeArr[i] = new  ColoredShape(shapeArr[0]);
            shapeArr[i].rotate(i*dTheta);
        }
        
        return shapeArr;
    }



    

    
}
